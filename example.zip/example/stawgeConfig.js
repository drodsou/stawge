export default {
  dist : '/dist'
}
